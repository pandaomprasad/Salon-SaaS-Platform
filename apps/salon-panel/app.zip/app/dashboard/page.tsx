"use client";

import { BOOKINGS, STAFF } from "@/lib/data";
import { User, Booking } from "@/lib/types";
import StatCard from "@/components/ui/StatCard";
import { StatusBadge } from "@/components/ui/Badge";
import { formatCurrency, formatDuration } from "@/lib/utils";
import { TrendingUp, CalendarDays, Users, Clock, Star } from "lucide-react";
import ProtectedRoute from "@/components/ProtectedRoute";
import { useFetch } from "@/hooks/useApi";

const TODAY = "2026-03-22";
import { browseBranches } from "@/api/services/browseService";
interface DashboardPageProps {
  user: User;
}

export default function DashboardPage({ user }: DashboardPageProps) {

  console.log("Access:", localStorage.getItem("token"))
  console.log("Refresh:", localStorage.getItem("refreshToken"))
  // const parsedToken = JSON.parse(atob(localStorage.getItem("token").split(".")[1]));
  fetch("http://localhost:6969/api/v1/browse/salons").then(r => r.json()).then(d => console.log("Salons:", d))
  fetch("http://localhost:6969/api/v1/auth/me", {
    headers: { Authorization: `Bearer ${localStorage.getItem("token")}` }
  }).then(r => r.json()).then(d => console.log("Me:", d))
  console.log()

  return (
    <ProtectedRoute>
      <ul>

      </ul>
    </ProtectedRoute>
  );
}


